var gridData = [{
        tests: 'test1',
        A: 8.2,
        B: 5.3,
        C: 6.5
    },
    {
        tests: 'test2',
        A: 4.2,
        B: 3.9,
        C: 5.3
    },
    {
        tests: 'test3',
        A: 2.2,
        B: 1.5,
        C: 3.2
    },
    {
        tests: 'test4',
        A: 1.2,
        B: 2.1,
        C: 12
    }
]